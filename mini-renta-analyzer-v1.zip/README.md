# Lottery Analysis Lab v1

Перша робоча статична PWA-версія для Android 11 і GitHub Pages.

## Запуск
Відкрийте `index.html` або опублікуйте всі файли через GitHub Pages.

## GitHub Pages
1. Створіть public repository.
2. Завантажте всі файли в корінь.
3. Settings → Pages → Deploy from a branch → main / root.

## Формат архіву
`YYYY-MM-DD,n1,n2,n3,n4,n5,n6,n7`

Це дослідницький статистичний інструмент, не прогноз і не гарантія виграшу.
